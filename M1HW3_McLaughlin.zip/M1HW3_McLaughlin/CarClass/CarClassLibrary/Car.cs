﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarClassLibrary
{
    
    public class Car
    {
        private int _year;
        private String _make;
        private int _speed;
        public Car(int year, String make, int speed)
        {
            year = _year;
            make = _make;
            speed = 0;
        }

        public static int accelerateSpeed(ref int speed)
        {
            int finalSpeed;
            finalSpeed = speed + 5;
            return finalSpeed;
        }

        public static int brakeOnSpeed(ref int speed)
        {
            int finalSpeed;
            finalSpeed = speed - 5;
            return finalSpeed;
        }

        public int year
        {
            get { return _year; }
            set { }
        }

        public int speed
        {
            get { return _speed; }
            set { }
        }

        public String make
        {
            get { return _make; }
            set { }
        }
    }
}
