﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CarClassLibrary;


/**
* 8/24/2022
* CSC 253
* Ciara McLaughlin
* This program has a car object within the program which then allows the user to either accelerate or decrease the car speed by 5.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        Car userCar = new Car(2004, "GMC", 0);
        int userSpeed = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void accelerateButton_Click(object sender, EventArgs e)
        {
            
            int finalSpeed;
            finalSpeed = Car.accelerateSpeed(ref userSpeed);
            speedTextBox.Text = finalSpeed.ToString("n");
            userSpeed = finalSpeed;
            

        }

        private void brakeButton_Click(object sender, EventArgs e)
        {
            
            int finalSpeed;
            
            if (userSpeed < 0)
            {
                MessageBox.Show("You can't go lower than 0!", "Error");
                finalSpeed = 0;
                speedTextBox.Text = finalSpeed.ToString("n");
            }
            else
            {
                finalSpeed = Car.brakeOnSpeed(ref userSpeed);
                speedTextBox.Text = finalSpeed.ToString("n");
                userSpeed = finalSpeed;
            }
    
        }
    }
}
