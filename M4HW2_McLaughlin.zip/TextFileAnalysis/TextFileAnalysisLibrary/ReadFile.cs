﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextFileAnalysisLibrary
{
    public class ReadFile
    {
        public static List<string> FileReader(string filename)
        {

            List<string> returnList1 = new List<string>();
            StreamReader inputfile;
            try
            {
                inputfile = File.OpenText(filename);

                while (inputfile.EndOfStream == false)
                {
                    string line = inputfile.ReadLine();
                    line.ToLower();
                    string[] tokens = line.Split(' ');

                    for (int i = 0; i < tokens.Length; i++)
                    {
                        if (char.IsPunctuation(tokens[i][tokens[i].Length - 1]))
                        {
                            tokens[i] = tokens[i].Remove(tokens[i].Length - 1, 1);
                        }

                        returnList1.Add(tokens[i]);
                    }
                    //returnList.Add(inputfile.ReadLine());
                }
                inputfile.Close();

                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.Read();
            }


            return returnList1;
        }

        public static List<string> FileReader2(string filename)
        {

            List<string> returnList1 = new List<string>();
            StreamReader inputfile;
            try
            {
                inputfile = File.OpenText(filename);

                while (inputfile.EndOfStream == false)
                {
                    string line = inputfile.ReadLine();
                    line.ToLower();
                    string[] tokens = line.Split(' ');

                    for (int i = 0; i < tokens.Length; i++)
                    {
                        if (char.IsPunctuation(tokens[i][tokens[i].Length - 1]))
                        {
                            tokens[i] = tokens[i].Remove(tokens[i].Length - 1, 1);
                        }

                        returnList1.Add(tokens[i]);
                    }
                    //returnList.Add(inputfile.ReadLine());
                }
                inputfile.Close();


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.Read();
            }


            return returnList1;
        }
    }
}
