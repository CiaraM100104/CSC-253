﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.wordsListBox = new System.Windows.Forms.ListBox();
            this.unique_both = new System.Windows.Forms.Button();
            this.words_both = new System.Windows.Forms.Button();
            this.first_file = new System.Windows.Forms.Button();
            this.second_file = new System.Windows.Forms.Button();
            this.first_second_notboth = new System.Windows.Forms.Button();
            this.select_file = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // wordsListBox
            // 
            this.wordsListBox.FormattingEnabled = true;
            this.wordsListBox.Location = new System.Drawing.Point(12, 120);
            this.wordsListBox.Name = "wordsListBox";
            this.wordsListBox.Size = new System.Drawing.Size(315, 264);
            this.wordsListBox.TabIndex = 0;
            // 
            // unique_both
            // 
            this.unique_both.Location = new System.Drawing.Point(12, 12);
            this.unique_both.Name = "unique_both";
            this.unique_both.Size = new System.Drawing.Size(157, 23);
            this.unique_both.TabIndex = 1;
            this.unique_both.Text = "Display Unique Words In Both";
            this.unique_both.UseVisualStyleBackColor = true;
            this.unique_both.Click += new System.EventHandler(this.unique_both_Click);
            // 
            // words_both
            // 
            this.words_both.Location = new System.Drawing.Point(12, 42);
            this.words_both.Name = "words_both";
            this.words_both.Size = new System.Drawing.Size(157, 23);
            this.words_both.TabIndex = 2;
            this.words_both.Text = "Display words in both";
            this.words_both.UseVisualStyleBackColor = true;
            this.words_both.Click += new System.EventHandler(this.words_both_Click);
            // 
            // first_file
            // 
            this.first_file.Location = new System.Drawing.Point(12, 72);
            this.first_file.Name = "first_file";
            this.first_file.Size = new System.Drawing.Size(157, 23);
            this.first_file.TabIndex = 3;
            this.first_file.Text = "Display First FIle Words";
            this.first_file.UseVisualStyleBackColor = true;
            this.first_file.Click += new System.EventHandler(this.first_file_Click);
            // 
            // second_file
            // 
            this.second_file.Location = new System.Drawing.Point(175, 12);
            this.second_file.Name = "second_file";
            this.second_file.Size = new System.Drawing.Size(151, 23);
            this.second_file.TabIndex = 4;
            this.second_file.Text = "Display Second File Words";
            this.second_file.UseVisualStyleBackColor = true;
            this.second_file.Click += new System.EventHandler(this.second_file_Click);
            // 
            // first_second_notboth
            // 
            this.first_second_notboth.Location = new System.Drawing.Point(176, 41);
            this.first_second_notboth.Name = "first_second_notboth";
            this.first_second_notboth.Size = new System.Drawing.Size(151, 23);
            this.first_second_notboth.TabIndex = 5;
            this.first_second_notboth.Text = "Display First and Second";
            this.first_second_notboth.UseVisualStyleBackColor = true;
            this.first_second_notboth.Click += new System.EventHandler(this.first_second_notboth_Click);
            // 
            // select_file
            // 
            this.select_file.Location = new System.Drawing.Point(175, 72);
            this.select_file.Name = "select_file";
            this.select_file.Size = new System.Drawing.Size(152, 23);
            this.select_file.TabIndex = 6;
            this.select_file.Text = "Select File";
            this.select_file.UseVisualStyleBackColor = true;
            this.select_file.Click += new System.EventHandler(this.select_file_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(376, 405);
            this.Controls.Add(this.select_file);
            this.Controls.Add(this.first_second_notboth);
            this.Controls.Add(this.second_file);
            this.Controls.Add(this.first_file);
            this.Controls.Add(this.words_both);
            this.Controls.Add(this.unique_both);
            this.Controls.Add(this.wordsListBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox wordsListBox;
        private System.Windows.Forms.Button unique_both;
        private System.Windows.Forms.Button words_both;
        private System.Windows.Forms.Button first_file;
        private System.Windows.Forms.Button second_file;
        private System.Windows.Forms.Button first_second_notboth;
        private System.Windows.Forms.Button select_file;
    }
}

