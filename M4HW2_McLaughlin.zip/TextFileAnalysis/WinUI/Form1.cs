﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TextFileAnalysisLibrary;

/**
* 10/23/2022
* CSC 253
* Ciara Mclaughlin
* This program allows the comparisons of two files.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        List<string> wordList1 = new List<string>();
        List<string> wordList2 = new List<string>();
        List<string> wordList3 = new List<string>();
        List<string> wordList4 = new List<string>();
        List<string> wordList5 = new List<string>();
        public Form1()
        {
            InitializeComponent();
        }

        private void select_file_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = ".";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                wordList1 = ReadFile.FileReader(openFileDialog.FileName);
            }

            OpenFileDialog openFileDialog2 = new OpenFileDialog();
            openFileDialog2.InitialDirectory = ".";

            if (openFileDialog2.ShowDialog() == DialogResult.OK)
            {
                wordList2 = ReadFile.FileReader2(openFileDialog2.FileName);
            }
        }

        private void unique_both_Click(object sender, EventArgs e)
        {
            var sortedList = from w in wordList1
                             orderby w
                             select w;
            var sortedList2 = from w in wordList2
                             orderby w
                             select w;

            foreach (var word in sortedList.Union(sortedList2))
            {
                wordsListBox.Items.Add(word);
            }

        }

        private void words_both_Click(object sender, EventArgs e)
        {
            var sortedList = from w in wordList1
                             orderby w
                             select w;
            var sortedList2 = from w in wordList2
                              orderby w
                              select w;
            foreach(var word in sortedList.Intersect(sortedList2))
            {
                wordsListBox.Items.Add(word);
            }

        }

        private void first_file_Click(object sender, EventArgs e)
        {
            var sortedList = from w in wordList1
                             orderby w
                             select w;
            var sortedList2 = from w in wordList2
                              orderby w
                              select w;
            foreach (var word in sortedList.Except(sortedList2))
            {
                wordsListBox.Items.Add(word);
            }
        }

        private void second_file_Click(object sender, EventArgs e)
        {
            var sortedList = from w in wordList1
                             orderby w
                             select w;
            var sortedList2 = from w in wordList2
                              orderby w
                              select w;
            foreach (var word in sortedList2.Except(sortedList))
            {
                wordsListBox.Items.Add(word);
            }
        }

        private void first_second_notboth_Click(object sender, EventArgs e)
        {
            var sortedList = from w in wordList1
                             orderby w
                             select w;
            var sortedList2 = from w in wordList2
                              orderby w
                              select w;
            foreach (var word in sortedList2.Except(sortedList))
            {
                wordsListBox.Items.Add(word);
            }
            foreach (var word in sortedList.Except(sortedList2))
            {
                wordsListBox.Items.Add(word);
            }
        }
    }
}
