﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using RetailPriceLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailPrice.Tests
{
    [TestClass()]
    public class RetailPriceTests
    {
        [TestMethod()]
        public void CalculateRetailTest()
        {
            double markup = 100;
            double wholesale = 5;
            double expected = 10.0;

            double actual = CalculatePrice.CalculateRetail(ref markup, wholesale);

            Assert.AreEqual(expected, actual);
        }
    }
}