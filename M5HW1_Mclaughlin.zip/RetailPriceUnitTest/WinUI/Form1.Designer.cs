﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.wholesale_TB = new System.Windows.Forms.TextBox();
            this.markup_TB = new System.Windows.Forms.TextBox();
            this.calcRetail = new System.Windows.Forms.Button();
            this.price_TB = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter whole-sale cost";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Enter mark-up price";
            // 
            // wholesale_TB
            // 
            this.wholesale_TB.Location = new System.Drawing.Point(128, 26);
            this.wholesale_TB.Name = "wholesale_TB";
            this.wholesale_TB.Size = new System.Drawing.Size(145, 20);
            this.wholesale_TB.TabIndex = 2;
            // 
            // markup_TB
            // 
            this.markup_TB.Location = new System.Drawing.Point(128, 53);
            this.markup_TB.Name = "markup_TB";
            this.markup_TB.Size = new System.Drawing.Size(145, 20);
            this.markup_TB.TabIndex = 3;
            // 
            // calcRetail
            // 
            this.calcRetail.Location = new System.Drawing.Point(128, 90);
            this.calcRetail.Name = "calcRetail";
            this.calcRetail.Size = new System.Drawing.Size(145, 58);
            this.calcRetail.TabIndex = 4;
            this.calcRetail.Text = "Calculate Retail Price";
            this.calcRetail.UseVisualStyleBackColor = true;
            this.calcRetail.Click += new System.EventHandler(this.calcRetail_Click);
            // 
            // price_TB
            // 
            this.price_TB.Location = new System.Drawing.Point(128, 172);
            this.price_TB.Name = "price_TB";
            this.price_TB.Size = new System.Drawing.Size(145, 20);
            this.price_TB.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(60, 175);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Retail Price";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(297, 224);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.price_TB);
            this.Controls.Add(this.calcRetail);
            this.Controls.Add(this.markup_TB);
            this.Controls.Add(this.wholesale_TB);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox wholesale_TB;
        private System.Windows.Forms.TextBox markup_TB;
        private System.Windows.Forms.Button calcRetail;
        private System.Windows.Forms.TextBox price_TB;
        private System.Windows.Forms.Label label3;
    }
}

