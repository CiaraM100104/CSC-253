﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RetailPriceLibrary;

/**
* 11/12/2022
* CSC 253
* Ciara McLaughlin
* This program calculates the retail price and has a unit test to check if the calculation is accurate.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calcRetail_Click(object sender, EventArgs e)
        {

            double markup;
            double wholesale;

            if (double.TryParse(wholesale_TB.Text, out wholesale) && double.TryParse(markup_TB.Text, out markup))
            {
                double retailPrice;
                retailPrice = CalculatePrice.CalculateRetail(ref markup, wholesale);
                price_TB.Text = retailPrice.ToString("C");
            }
            else
            {
                MessageBox.Show("Please enter valid numbers", "Invalid Input");
            }
        }
    }
}
