﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailPriceLibrary
{
    public class CalculatePrice
    {
        public static double CalculateRetail(ref double markup, double wholesale)
        {
            double markupPercent = markup / 100;
            double retailPrice;

            retailPrice = wholesale + (wholesale * markupPercent);
            return retailPrice;
        }
    }
}
