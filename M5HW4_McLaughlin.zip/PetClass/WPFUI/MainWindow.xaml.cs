﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PetClassLibrary;

namespace WPFUI
{
    /**
    * 11/21/2022
    * CSC 253
    * Ciara McLaughlin
    * This program will allow a user to enter pet information in a WPF form and have it displayed back to them.
    */

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void display_Button_Click(object sender, RoutedEventArgs e)
        {
            pet_LB.Items.Clear();
            Pet myPet = new Pet(name_TB.Text, type_TB.Text, int.Parse(age_TB.Text));
            pet_LB.Items.Add("Name: " + myPet.Name + "\n" +
                             "Type: " + myPet.Type + "\n" +
                             "Age: " + myPet.Age);
        }
    }
}
