﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PopulationDatabaseLibrary;

/**
* 9/25/2022
* CSC 253
* Ciara McLaughlin
* This program loads data of cities and allows the user to manipulate it by sorting it.
*/

namespace WinUi
{

    public partial class Form1 : Form

    {
        List<CityClass> city = new List<CityClass>();
        public Form1()
        {
            InitializeComponent();
            LoadCityList();
            ShowCityList();
        }

        private void LoadCityList()
        {
            city = SQLiteDataAccess.LoadCity();
        }

        private void ShowCityList()
        {
            CityList.DataSource = null;
            CityList.DataSource = city;
            CityList.DisplayMember = "City";

            PopulationList.DataSource = null;
            PopulationList.DataSource = city;
            PopulationList.DisplayMember = "Population";

        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            city = SQLiteDataAccess.SearchPeople(searchText.Text);
            ShowCityList();
        }

        private void totalButton_Click(object sender, EventArgs e)
        {
            totalText.Text = SQLiteDataAccess.TotalPopulation();        
        }

        private void avgButton_Click(object sender, EventArgs e)
        {
            avgBox.Text = SQLiteDataAccess.AveragePop();
        }

        private void highestButton_Click(object sender, EventArgs e)
        {
            highBox.Text = SQLiteDataAccess.MaxPopulation();
        }

        private void lowestButton_Click(object sender, EventArgs e)
        {
            lowBox.Text = SQLiteDataAccess.MinPopulation();
        }

        private void ascButton_Click(object sender, EventArgs e)
        {
            city = SQLiteDataAccess.AscendingOrder();
            ShowCityList();
        }

        private void dscButton_Click(object sender, EventArgs e)
        {
            city = SQLiteDataAccess.DescendingOrder();
            ShowCityList();
        }
    }
}
