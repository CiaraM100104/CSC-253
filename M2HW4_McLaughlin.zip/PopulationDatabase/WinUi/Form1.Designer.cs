﻿
namespace WinUi
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CityList = new System.Windows.Forms.ListBox();
            this.PopulationList = new System.Windows.Forms.ListBox();
            this.ascButton = new System.Windows.Forms.Button();
            this.dscButton = new System.Windows.Forms.Button();
            this.avgButton = new System.Windows.Forms.Button();
            this.highestButton = new System.Windows.Forms.Button();
            this.totalButton = new System.Windows.Forms.Button();
            this.searchButton = new System.Windows.Forms.Button();
            this.searchText = new System.Windows.Forms.TextBox();
            this.avgBox = new System.Windows.Forms.TextBox();
            this.lowestButton = new System.Windows.Forms.Button();
            this.City = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.totalText = new System.Windows.Forms.TextBox();
            this.highBox = new System.Windows.Forms.TextBox();
            this.lowBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // CityList
            // 
            this.CityList.FormattingEnabled = true;
            this.CityList.Location = new System.Drawing.Point(11, 52);
            this.CityList.Name = "CityList";
            this.CityList.Size = new System.Drawing.Size(158, 251);
            this.CityList.TabIndex = 0;
            // 
            // PopulationList
            // 
            this.PopulationList.FormattingEnabled = true;
            this.PopulationList.Location = new System.Drawing.Point(193, 52);
            this.PopulationList.Name = "PopulationList";
            this.PopulationList.Size = new System.Drawing.Size(181, 251);
            this.PopulationList.TabIndex = 1;
            // 
            // ascButton
            // 
            this.ascButton.Location = new System.Drawing.Point(400, 280);
            this.ascButton.Name = "ascButton";
            this.ascButton.Size = new System.Drawing.Size(119, 23);
            this.ascButton.TabIndex = 2;
            this.ascButton.Text = "Sort by Ascending";
            this.ascButton.UseVisualStyleBackColor = true;
            this.ascButton.Click += new System.EventHandler(this.ascButton_Click);
            // 
            // dscButton
            // 
            this.dscButton.Location = new System.Drawing.Point(525, 280);
            this.dscButton.Name = "dscButton";
            this.dscButton.Size = new System.Drawing.Size(128, 23);
            this.dscButton.TabIndex = 3;
            this.dscButton.Text = "Sort by Descending";
            this.dscButton.UseVisualStyleBackColor = true;
            this.dscButton.Click += new System.EventHandler(this.dscButton_Click);
            // 
            // avgButton
            // 
            this.avgButton.Location = new System.Drawing.Point(387, 117);
            this.avgButton.Name = "avgButton";
            this.avgButton.Size = new System.Drawing.Size(132, 23);
            this.avgButton.TabIndex = 4;
            this.avgButton.Text = "Get Average Population";
            this.avgButton.UseVisualStyleBackColor = true;
            this.avgButton.Click += new System.EventHandler(this.avgButton_Click);
            // 
            // highestButton
            // 
            this.highestButton.Location = new System.Drawing.Point(387, 146);
            this.highestButton.Name = "highestButton";
            this.highestButton.Size = new System.Drawing.Size(132, 23);
            this.highestButton.TabIndex = 5;
            this.highestButton.Text = "Get Highest Population";
            this.highestButton.UseVisualStyleBackColor = true;
            this.highestButton.Click += new System.EventHandler(this.highestButton_Click);
            // 
            // totalButton
            // 
            this.totalButton.Location = new System.Drawing.Point(387, 88);
            this.totalButton.Name = "totalButton";
            this.totalButton.Size = new System.Drawing.Size(119, 23);
            this.totalButton.TabIndex = 6;
            this.totalButton.Text = "Get Total Population";
            this.totalButton.UseVisualStyleBackColor = true;
            this.totalButton.Click += new System.EventHandler(this.totalButton_Click);
            // 
            // searchButton
            // 
            this.searchButton.Location = new System.Drawing.Point(387, 59);
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(119, 23);
            this.searchButton.TabIndex = 8;
            this.searchButton.Text = "Search By Name";
            this.searchButton.UseVisualStyleBackColor = true;
            this.searchButton.Click += new System.EventHandler(this.searchButton_Click);
            // 
            // searchText
            // 
            this.searchText.Location = new System.Drawing.Point(512, 59);
            this.searchText.Name = "searchText";
            this.searchText.Size = new System.Drawing.Size(224, 20);
            this.searchText.TabIndex = 9;
            // 
            // avgBox
            // 
            this.avgBox.Location = new System.Drawing.Point(525, 117);
            this.avgBox.Name = "avgBox";
            this.avgBox.Size = new System.Drawing.Size(223, 20);
            this.avgBox.TabIndex = 10;
            // 
            // lowestButton
            // 
            this.lowestButton.Location = new System.Drawing.Point(387, 175);
            this.lowestButton.Name = "lowestButton";
            this.lowestButton.Size = new System.Drawing.Size(144, 23);
            this.lowestButton.TabIndex = 11;
            this.lowestButton.Text = "Get Lowest Population";
            this.lowestButton.UseVisualStyleBackColor = true;
            this.lowestButton.Click += new System.EventHandler(this.lowestButton_Click);
            // 
            // City
            // 
            this.City.AutoSize = true;
            this.City.Location = new System.Drawing.Point(60, 33);
            this.City.Name = "City";
            this.City.Size = new System.Drawing.Size(24, 13);
            this.City.TabIndex = 12;
            this.City.Text = "City";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(256, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Population";
            // 
            // totalText
            // 
            this.totalText.Location = new System.Drawing.Point(513, 88);
            this.totalText.Name = "totalText";
            this.totalText.Size = new System.Drawing.Size(223, 20);
            this.totalText.TabIndex = 15;
            // 
            // highBox
            // 
            this.highBox.Location = new System.Drawing.Point(526, 148);
            this.highBox.Name = "highBox";
            this.highBox.Size = new System.Drawing.Size(222, 20);
            this.highBox.TabIndex = 16;
            // 
            // lowBox
            // 
            this.lowBox.Location = new System.Drawing.Point(538, 177);
            this.lowBox.Name = "lowBox";
            this.lowBox.Size = new System.Drawing.Size(210, 20);
            this.lowBox.TabIndex = 17;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 330);
            this.Controls.Add(this.lowBox);
            this.Controls.Add(this.highBox);
            this.Controls.Add(this.totalText);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.City);
            this.Controls.Add(this.lowestButton);
            this.Controls.Add(this.avgBox);
            this.Controls.Add(this.searchText);
            this.Controls.Add(this.searchButton);
            this.Controls.Add(this.totalButton);
            this.Controls.Add(this.highestButton);
            this.Controls.Add(this.avgButton);
            this.Controls.Add(this.dscButton);
            this.Controls.Add(this.ascButton);
            this.Controls.Add(this.PopulationList);
            this.Controls.Add(this.CityList);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox CityList;
        private System.Windows.Forms.ListBox PopulationList;
        private System.Windows.Forms.Button ascButton;
        private System.Windows.Forms.Button dscButton;
        private System.Windows.Forms.Button avgButton;
        private System.Windows.Forms.Button highestButton;
        private System.Windows.Forms.Button totalButton;
        private System.Windows.Forms.Button searchButton;
        private System.Windows.Forms.TextBox searchText;
        private System.Windows.Forms.TextBox avgBox;
        private System.Windows.Forms.Button lowestButton;
        private System.Windows.Forms.Label City;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox totalText;
        private System.Windows.Forms.TextBox highBox;
        private System.Windows.Forms.TextBox lowBox;
    }
}

