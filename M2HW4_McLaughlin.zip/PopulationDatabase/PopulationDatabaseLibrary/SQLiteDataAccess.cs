﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PopulationDatabaseLibrary
{
    public class SQLiteDataAccess
    {
        public static List<CityClass> LoadCity()
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var output = cnn.Query<CityClass>("SELECT * FROM City", new DynamicParameters());
                return output.ToList();
            }
        }

        private static string LoadConnectionString(string id = "Default")
        {
            return ConfigurationManager.ConnectionStrings[id].ConnectionString;
        }

        public static List<CityClass> AscendingOrder()
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var output = cnn.Query<CityClass>("SELECT * FROM City ORDER BY Population ASC", new DynamicParameters());
                return output.ToList();
            }
        }

        public static List<CityClass> DescendingOrder()
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var output = cnn.Query<CityClass>("SELECT * FROM City ORDER BY Population DESC", new DynamicParameters());
                return output.ToList();
            }
        }

        public static List<CityClass> SearchPeople(String input)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var output = cnn.Query<CityClass>("SELECT * FROM City WHERE City LIKE @a", new { a = input + "%" });
                return output.ToList();
            }
        }

        public static string TotalPopulation()
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var output = cnn.ExecuteScalar<double>("SELECT SUM(Population) FROM City", new DynamicParameters());
                return output.ToString();
            }
        }

        public static string AveragePop()
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var output = cnn.ExecuteScalar<double>("SELECT Avg(Population) FROM City", new DynamicParameters());
                return output.ToString();
            }
        }

        public static string MaxPopulation()
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var output = cnn.ExecuteScalar<double>("SELECT MAX(Population) FROM City", new DynamicParameters());
                return output.ToString();
            }
        }

        public static string MinPopulation()
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var output = cnn.ExecuteScalar<double>("SELECT MIN(Population) FROM City", new DynamicParameters());
                return output.ToString();
            }
        }
    }
}
