﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreaClassLibrary
{
    public class CalculateArea
    {
        public static double calculateArea(double radius)
        {

            double area =  Math.PI * Math.Pow(radius, 2);
            return area;
        }

        public static int calculateArea(int width, int length)
        {

            int area = width * length;
            return area;
        }

        public static double calculateArea(double radius, double height)
        {
            double area = Math.PI * Math.Pow(radius, 2) * height;
            return area;

        }
    }
}
