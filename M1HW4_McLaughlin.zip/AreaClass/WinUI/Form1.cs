﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AreaClassLibrary;

/**
* 8/26/2022
* CSC 253
* Ciara McLaughlin
* This program demonstrates overloaded methods and displays an area of 3 different shapes to the user.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void getAreas_Click(object sender, EventArgs e)
        {
            int rectangleArea;
            double circleArea;
            double cylinderArea;

            rectangleArea = CalculateArea.calculateArea(10, 15);
            circleArea = CalculateArea.calculateArea(10.0);
            cylinderArea = CalculateArea.calculateArea(2.0, 7.0);

            rectangleAreaTextBox.Text = "The area for a rectangle with 10 width and 15 height is " + rectangleArea.ToString("n");
            cylinderAreaTextBox.Text = "The area for a cylinder with 2.0 as a radius and 7.0 as a height is " + cylinderArea.ToString("n");
            circleAreaTextBox.Text = "The area for a circle with 10.0 as a radius is " + circleArea.ToString("n");
        }
    }
}
