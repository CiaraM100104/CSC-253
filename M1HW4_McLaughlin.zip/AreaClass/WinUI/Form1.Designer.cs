﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.circleAreaTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.rectangleAreaTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cylinderAreaTextBox = new System.Windows.Forms.TextBox();
            this.getAreas = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(95, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Get the area of a circle";
            // 
            // circleAreaTextBox
            // 
            this.circleAreaTextBox.Location = new System.Drawing.Point(12, 29);
            this.circleAreaTextBox.Multiline = true;
            this.circleAreaTextBox.Name = "circleAreaTextBox";
            this.circleAreaTextBox.Size = new System.Drawing.Size(287, 58);
            this.circleAreaTextBox.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(95, 135);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Get the area of a rectangle";
            // 
            // rectangleAreaTextBox
            // 
            this.rectangleAreaTextBox.Location = new System.Drawing.Point(12, 151);
            this.rectangleAreaTextBox.Multiline = true;
            this.rectangleAreaTextBox.Name = "rectangleAreaTextBox";
            this.rectangleAreaTextBox.Size = new System.Drawing.Size(287, 63);
            this.rectangleAreaTextBox.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(95, 240);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(126, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Get the area of a cylinder";
            // 
            // cylinderAreaTextBox
            // 
            this.cylinderAreaTextBox.Location = new System.Drawing.Point(12, 256);
            this.cylinderAreaTextBox.Multiline = true;
            this.cylinderAreaTextBox.Name = "cylinderAreaTextBox";
            this.cylinderAreaTextBox.Size = new System.Drawing.Size(287, 69);
            this.cylinderAreaTextBox.TabIndex = 5;
            // 
            // getAreas
            // 
            this.getAreas.Location = new System.Drawing.Point(125, 342);
            this.getAreas.Name = "getAreas";
            this.getAreas.Size = new System.Drawing.Size(75, 23);
            this.getAreas.TabIndex = 6;
            this.getAreas.Text = "Get Areas";
            this.getAreas.UseVisualStyleBackColor = true;
            this.getAreas.Click += new System.EventHandler(this.getAreas_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(326, 388);
            this.Controls.Add(this.getAreas);
            this.Controls.Add(this.cylinderAreaTextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.rectangleAreaTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.circleAreaTextBox);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "AreasOfShapes";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox circleAreaTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox rectangleAreaTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox cylinderAreaTextBox;
        private System.Windows.Forms.Button getAreas;
    }
}

