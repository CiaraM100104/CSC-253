﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.name_LB = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.search_TB = new System.Windows.Forms.TextBox();
            this.short_TB = new System.Windows.Forms.TextBox();
            this.long_TB = new System.Windows.Forms.TextBox();
            this.LongButton = new System.Windows.Forms.Button();
            this.shortButton = new System.Windows.Forms.Button();
            this.searchName = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // name_LB
            // 
            this.name_LB.FormattingEnabled = true;
            this.name_LB.Location = new System.Drawing.Point(32, 82);
            this.name_LB.Name = "name_LB";
            this.name_LB.Size = new System.Drawing.Size(348, 355);
            this.name_LB.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Find Names Longer Than";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Find Names Shorter Than";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(-1, 52);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Search/Specific Name";
            // 
            // search_TB
            // 
            this.search_TB.Location = new System.Drawing.Point(120, 49);
            this.search_TB.Name = "search_TB";
            this.search_TB.Size = new System.Drawing.Size(205, 20);
            this.search_TB.TabIndex = 4;
            // 
            // short_TB
            // 
            this.short_TB.Location = new System.Drawing.Point(162, 30);
            this.short_TB.Name = "short_TB";
            this.short_TB.Size = new System.Drawing.Size(123, 20);
            this.short_TB.TabIndex = 5;
            // 
            // long_TB
            // 
            this.long_TB.Location = new System.Drawing.Point(165, 6);
            this.long_TB.Name = "long_TB";
            this.long_TB.Size = new System.Drawing.Size(120, 20);
            this.long_TB.TabIndex = 6;
            // 
            // LongButton
            // 
            this.LongButton.Location = new System.Drawing.Point(292, 6);
            this.LongButton.Name = "LongButton";
            this.LongButton.Size = new System.Drawing.Size(75, 23);
            this.LongButton.TabIndex = 7;
            this.LongButton.Text = "Find";
            this.LongButton.UseVisualStyleBackColor = true;
            this.LongButton.Click += new System.EventHandler(this.LongButton_Click);
            // 
            // shortButton
            // 
            this.shortButton.Location = new System.Drawing.Point(292, 27);
            this.shortButton.Name = "shortButton";
            this.shortButton.Size = new System.Drawing.Size(75, 23);
            this.shortButton.TabIndex = 8;
            this.shortButton.Text = "Find";
            this.shortButton.UseVisualStyleBackColor = true;
            this.shortButton.Click += new System.EventHandler(this.shortButton_Click);
            // 
            // searchName
            // 
            this.searchName.Location = new System.Drawing.Point(331, 49);
            this.searchName.Name = "searchName";
            this.searchName.Size = new System.Drawing.Size(75, 23);
            this.searchName.TabIndex = 9;
            this.searchName.Text = "search";
            this.searchName.UseVisualStyleBackColor = true;
            this.searchName.Click += new System.EventHandler(this.searchName_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(427, 450);
            this.Controls.Add(this.searchName);
            this.Controls.Add(this.shortButton);
            this.Controls.Add(this.LongButton);
            this.Controls.Add(this.long_TB);
            this.Controls.Add(this.short_TB);
            this.Controls.Add(this.search_TB);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.name_LB);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox name_LB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox search_TB;
        private System.Windows.Forms.TextBox short_TB;
        private System.Windows.Forms.TextBox long_TB;
        private System.Windows.Forms.Button LongButton;
        private System.Windows.Forms.Button shortButton;
        private System.Windows.Forms.Button searchName;
    }
}

