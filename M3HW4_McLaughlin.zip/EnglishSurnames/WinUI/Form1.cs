﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EnglishSurnamesLibrary;

/**
* 10/9/2022
* CSC 253
* Ciara McLaughlin
* This program will allow a user to sort through names.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        List<string> namesList = Readfile.FileReader();
        public Form1()
        {
            InitializeComponent();
            ShowNames();
        }

        private void ShowNames()
        {
            name_LB.DataSource = null;
            name_LB.DataSource = namesList;
            name_LB.DisplayMember = "Name";
        }

        private void searchName_Click_1(object sender, EventArgs e)
        {
            namesList = SortNames.NameSearch(search_TB.Text, namesList);
            ShowNames();
            namesList = Readfile.FileReader();
        }

        private void shortButton_Click(object sender, EventArgs e)
        {
            namesList = SortNames.NameShorter(short_TB.Text, namesList);
            ShowNames();
            namesList = Readfile.FileReader();
        }

        private void LongButton_Click(object sender, EventArgs e)
        {
            namesList = SortNames.NameLonger(long_TB.Text, namesList);
            ShowNames();
            namesList = Readfile.FileReader();
        }
    }
}
