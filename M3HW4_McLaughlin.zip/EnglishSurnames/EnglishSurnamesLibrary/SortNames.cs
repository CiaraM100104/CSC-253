﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnglishSurnamesLibrary
{
    public class SortNames
    {
        public static List<string> NameSearch(String input, List<string> nameList)
        {

            nameList = nameList.FindAll(n => n.StartsWith(input, StringComparison.InvariantCultureIgnoreCase));
            return nameList;
        }

        public static List<string> NameShorter(String input, List<string> nameList)
        {
            int shorter;
            int.TryParse(input, out shorter);
            nameList = nameList.FindAll(n => n.Length < shorter);
            return nameList;
        }

        public static List<string> NameLonger(String input, List<string> nameList)
        {
            int longer;
            int.TryParse(input, out longer);
            nameList = nameList.FindAll(n => n.Length > longer);
            return nameList;
        }
    }
}
