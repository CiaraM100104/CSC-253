﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.bathroomSearch = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.bedRoom = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.squareFeetText = new System.Windows.Forms.TextBox();
            this.priceList = new System.Windows.Forms.ListBox();
            this.searchButton = new System.Windows.Forms.Button();
            this.bedroomList = new System.Windows.Forms.ListBox();
            this.bathroomList = new System.Windows.Forms.ListBox();
            this.squareFeetList = new System.Windows.Forms.ListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(152, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(281, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Please Enter a Range Like 100-200 or a Singular Number.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Bathrooms";
            // 
            // bathroomSearch
            // 
            this.bathroomSearch.Location = new System.Drawing.Point(87, 42);
            this.bathroomSearch.Name = "bathroomSearch";
            this.bathroomSearch.Size = new System.Drawing.Size(125, 20);
            this.bathroomSearch.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(246, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Bedroom";
            // 
            // bedRoom
            // 
            this.bedRoom.Location = new System.Drawing.Point(301, 42);
            this.bedRoom.Name = "bedRoom";
            this.bedRoom.Size = new System.Drawing.Size(132, 20);
            this.bedRoom.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(460, 45);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Square Feet";
            // 
            // squareFeetText
            // 
            this.squareFeetText.Location = new System.Drawing.Point(531, 42);
            this.squareFeetText.Name = "squareFeetText";
            this.squareFeetText.Size = new System.Drawing.Size(133, 20);
            this.squareFeetText.TabIndex = 6;
            // 
            // priceList
            // 
            this.priceList.FormattingEnabled = true;
            this.priceList.Location = new System.Drawing.Point(27, 132);
            this.priceList.Name = "priceList";
            this.priceList.Size = new System.Drawing.Size(128, 290);
            this.priceList.TabIndex = 7;
            // 
            // searchButton
            // 
            this.searchButton.Location = new System.Drawing.Point(293, 83);
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(140, 23);
            this.searchButton.TabIndex = 8;
            this.searchButton.Text = "Search";
            this.searchButton.UseVisualStyleBackColor = true;
            this.searchButton.Click += new System.EventHandler(this.searchButton_Click);
            // 
            // bedroomList
            // 
            this.bedroomList.FormattingEnabled = true;
            this.bedroomList.Location = new System.Drawing.Point(175, 132);
            this.bedroomList.Name = "bedroomList";
            this.bedroomList.Size = new System.Drawing.Size(136, 290);
            this.bedroomList.TabIndex = 9;
            // 
            // bathroomList
            // 
            this.bathroomList.FormattingEnabled = true;
            this.bathroomList.Location = new System.Drawing.Point(346, 132);
            this.bathroomList.Name = "bathroomList";
            this.bathroomList.Size = new System.Drawing.Size(147, 290);
            this.bathroomList.TabIndex = 10;
            // 
            // squareFeetList
            // 
            this.squareFeetList.FormattingEnabled = true;
            this.squareFeetList.Location = new System.Drawing.Point(531, 132);
            this.squareFeetList.Name = "squareFeetList";
            this.squareFeetList.Size = new System.Drawing.Size(140, 290);
            this.squareFeetList.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(73, 116);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Price";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(212, 116);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Bedrooms";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(392, 116);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Bathroom";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(565, 116);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "Square Feet";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(703, 450);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.squareFeetList);
            this.Controls.Add(this.bathroomList);
            this.Controls.Add(this.bedroomList);
            this.Controls.Add(this.searchButton);
            this.Controls.Add(this.priceList);
            this.Controls.Add(this.squareFeetText);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.bedRoom);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.bathroomSearch);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox bathroomSearch;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox bedRoom;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox squareFeetText;
        private System.Windows.Forms.ListBox priceList;
        private System.Windows.Forms.Button searchButton;
        private System.Windows.Forms.ListBox bedroomList;
        private System.Windows.Forms.ListBox bathroomList;
        private System.Windows.Forms.ListBox squareFeetList;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
    }
}

