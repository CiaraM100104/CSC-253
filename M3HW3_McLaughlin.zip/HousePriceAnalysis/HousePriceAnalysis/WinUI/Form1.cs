﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HousePriceAnalysisLibrary;

/**
* 10/8/2022
* CSC 253
* Ciara McLaughlin
* This program sorts through houses.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            House jfbajdfa = new House(72, 27, 17, 2);
            InitializeComponent();
            House.HouseGetter();
            ShowHouses();
           

        }

        private void ShowHouses()
        {
            priceList.DataSource = null;
            priceList.DataSource = House.Houses;
            priceList.DisplayMember = "Price";

            bedroomList.DataSource = null;
            bedroomList.DataSource = House.Houses;
            bedroomList.DisplayMember = "Bedroom";

            bathroomList.DataSource = null;
            bathroomList.DataSource = House.Houses;
            bathroomList.DisplayMember = "Bathroom";

            squareFeetList.DataSource = null;
            squareFeetList.DataSource = House.Houses;
            squareFeetList.DisplayMember = "SquareFeet";

        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            House.Houses = GetSearchInfo.BathroomSearch(bathroomSearch.Text, House.Houses);
            House.Houses = GetSearchInfo.BedroomSearch(bedRoom.Text, House.Houses);
            House.Houses = GetSearchInfo.SquareFeetSearch(squareFeetText.Text, House.Houses);
            ShowHouses();
            House.HouseGetter();
        }
    }
}
