﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HousePriceAnalysisLibrary
{
    public class GetSearchInfo
    {
        public static List<House> BathroomSearch(String input, List<House> houseList)
        {
            string[] tokens = input.Split('-');
            double range1, range2 = 0;
            double.TryParse(tokens[0], out range1);
            if (tokens.Length == 2)
            {
                double.TryParse(tokens[1], out range2);
                houseList = houseList.FindAll(n => n.Bathroom >= range1 && n.Bathroom <= range2);
            }
            else if (tokens.Length == 1)
            {
                houseList = houseList.FindAll(n => n.Bathroom == range1);
            }

            return houseList;
        }

        public static List<House> BedroomSearch(String input, List<House> houseList)
        {
            string[] tokens = input.Split('-');
            double range1, range2 = 0;
            double.TryParse(tokens[0], out range1);
            if (tokens.Length == 2)
            {
                double.TryParse(tokens[1], out range2);
                houseList = houseList.FindAll(n => n.Bedroom >= range1 && n.Bedroom <= range2);
            }
            else if (tokens.Length == 1)
            {
                houseList = houseList.FindAll(n => n.Bedroom == range1);
            }

            return houseList;
        }

        public static List<House> SquareFeetSearch(String input, List<House> houseList)
        {
            string[] tokens = input.Split('-');
            double range1, range2 = 0;
            double.TryParse(tokens[0], out range1);
            if (tokens.Length == 2)
            {
                double.TryParse(tokens[1], out range2);
                houseList = houseList.FindAll(n => n.SquareFeet >= range1 && n.SquareFeet <= range2);
            }
            else if (tokens.Length == 1)
            {
                houseList = houseList.FindAll(n => n.SquareFeet == range1);
            }

            return houseList;
        }
    }
}
