﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HousePriceAnalysisLibrary
{
    public class House
    {
        public House()
        {

        }
  
        public House(double price, int bedroom, double bathroom, int squareFeet)
        {
            price = Price;
            bedroom = Bedroom;
            bathroom = Bathroom;
            squareFeet = SquareFeet;
        }
        public double Price { get; set; }
        public int Bedroom { get; set; }
        public double Bathroom { get; set; }

        public int SquareFeet { get; set; }

        public static List<string> houses = ReadFile.FileReader("house_prices.csv");
        public static List<House> Houses = new List<House>();

        public static void HouseGetter()
        {
            foreach (string house in houses)
            {
                string[] tokens = house.Split(',');
                double.TryParse(tokens[0], out double price);
                int.TryParse(tokens[1], out int bedroom);
                int.TryParse(tokens[2], out int bathroom);
                int.TryParse(tokens[3], out int squareFeet);
                House newHouse = new House();
                newHouse.Bathroom = bathroom;
                newHouse.Price = price;
                newHouse.Bedroom = bedroom;
                newHouse.SquareFeet = squareFeet;
                Houses.Add(newHouse);

            }
        }


    }

}
