﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.employeeList = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.nameList = new System.Windows.Forms.ListBox();
            this.positionList = new System.Windows.Forms.ListBox();
            this.hourlyRateList = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.sortAsc = new System.Windows.Forms.Button();
            this.sortDsc = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // employeeList
            // 
            this.employeeList.FormattingEnabled = true;
            this.employeeList.Location = new System.Drawing.Point(12, 28);
            this.employeeList.Name = "employeeList";
            this.employeeList.Size = new System.Drawing.Size(120, 225);
            this.employeeList.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(45, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Employee ID";
            // 
            // nameList
            // 
            this.nameList.FormattingEnabled = true;
            this.nameList.Location = new System.Drawing.Point(159, 28);
            this.nameList.Name = "nameList";
            this.nameList.Size = new System.Drawing.Size(130, 225);
            this.nameList.TabIndex = 2;
            // 
            // positionList
            // 
            this.positionList.FormattingEnabled = true;
            this.positionList.Location = new System.Drawing.Point(319, 28);
            this.positionList.Name = "positionList";
            this.positionList.Size = new System.Drawing.Size(137, 225);
            this.positionList.TabIndex = 3;
            // 
            // hourlyRateList
            // 
            this.hourlyRateList.FormattingEnabled = true;
            this.hourlyRateList.Location = new System.Drawing.Point(482, 28);
            this.hourlyRateList.Name = "hourlyRateList";
            this.hourlyRateList.Size = new System.Drawing.Size(145, 225);
            this.hourlyRateList.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(212, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(372, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Position";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(522, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Hourly Pay";
            // 
            // sortAsc
            // 
            this.sortAsc.Location = new System.Drawing.Point(160, 284);
            this.sortAsc.Name = "sortAsc";
            this.sortAsc.Size = new System.Drawing.Size(129, 23);
            this.sortAsc.TabIndex = 8;
            this.sortAsc.Text = "Sort by Ascending";
            this.sortAsc.UseVisualStyleBackColor = true;
            this.sortAsc.Click += new System.EventHandler(this.sortAsc_Click);
            // 
            // sortDsc
            // 
            this.sortDsc.Location = new System.Drawing.Point(331, 284);
            this.sortDsc.Name = "sortDsc";
            this.sortDsc.Size = new System.Drawing.Size(125, 23);
            this.sortDsc.TabIndex = 9;
            this.sortDsc.Text = "Sort by Descending";
            this.sortDsc.UseVisualStyleBackColor = true;
            this.sortDsc.Click += new System.EventHandler(this.sortDsc_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(641, 324);
            this.Controls.Add(this.sortDsc);
            this.Controls.Add(this.sortAsc);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.hourlyRateList);
            this.Controls.Add(this.positionList);
            this.Controls.Add(this.nameList);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.employeeList);
            this.Name = "Form1";
            this.Text = " ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox employeeList;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox nameList;
        private System.Windows.Forms.ListBox positionList;
        private System.Windows.Forms.ListBox hourlyRateList;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button sortAsc;
        private System.Windows.Forms.Button sortDsc;
    }
}

