﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HourlyPaySorterLibrary;

/**
* 9/17/2022
* CSC 253
* Ciara McLaughlin
* This program loads a database and allows them to sort it by either ascending order or descending order.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        List<Employee> employee = new List<Employee>();
        public Form1()
        {
            InitializeComponent();
            LoadPeopleList();
            WireUpPeopleList();
        }

        private void LoadPeopleList()
        {
            employee = SQLiteDataAccess.LoadPeople();
        }

        private void WireUpPeopleList()
        {
            employeeList.DataSource = null;
            employeeList.DataSource = employee;
            employeeList.DisplayMember = "employeeID";

            nameList.DataSource = null;
            nameList.DataSource = employee;
            nameList.DisplayMember = "name";

            positionList.DataSource = null;
            positionList.DataSource = employee;
            positionList.DisplayMember = "position";

            hourlyRateList.DataSource = null;
            hourlyRateList.DataSource = employee;
            hourlyRateList.DisplayMember = "hourlyPayRate";
        }

        private void sortAsc_Click(object sender, EventArgs e)
        {
            employee = SQLiteDataAccess.AscendingOrder();
            WireUpPeopleList();
        }

        private void sortDsc_Click(object sender, EventArgs e)
        {
            employee = SQLiteDataAccess.DescendingOrder();
            WireUpPeopleList();
        }
    }
}
