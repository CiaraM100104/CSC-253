﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.productListBox = new System.Windows.Forms.ListBox();
            this.productSearchTB = new System.Windows.Forms.TextBox();
            this.search_ProductNum = new System.Windows.Forms.Button();
            this.descSearchTB = new System.Windows.Forms.TextBox();
            this.search_Desc = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // productListBox
            // 
            this.productListBox.FormattingEnabled = true;
            this.productListBox.Location = new System.Drawing.Point(12, 63);
            this.productListBox.Name = "productListBox";
            this.productListBox.Size = new System.Drawing.Size(580, 238);
            this.productListBox.TabIndex = 0;
            // 
            // productSearchTB
            // 
            this.productSearchTB.Location = new System.Drawing.Point(109, 6);
            this.productSearchTB.Name = "productSearchTB";
            this.productSearchTB.Size = new System.Drawing.Size(100, 20);
            this.productSearchTB.TabIndex = 1;
            // 
            // search_ProductNum
            // 
            this.search_ProductNum.Location = new System.Drawing.Point(215, 4);
            this.search_ProductNum.Name = "search_ProductNum";
            this.search_ProductNum.Size = new System.Drawing.Size(75, 23);
            this.search_ProductNum.TabIndex = 2;
            this.search_ProductNum.Text = "Search";
            this.search_ProductNum.UseVisualStyleBackColor = true;
            this.search_ProductNum.Click += new System.EventHandler(this.search_ProductNum_Click);
            // 
            // descSearchTB
            // 
            this.descSearchTB.Location = new System.Drawing.Point(411, 6);
            this.descSearchTB.Name = "descSearchTB";
            this.descSearchTB.Size = new System.Drawing.Size(100, 20);
            this.descSearchTB.TabIndex = 3;
            // 
            // search_Desc
            // 
            this.search_Desc.Location = new System.Drawing.Point(517, 4);
            this.search_Desc.Name = "search_Desc";
            this.search_Desc.Size = new System.Drawing.Size(75, 23);
            this.search_Desc.TabIndex = 4;
            this.search_Desc.Text = "Search";
            this.search_Desc.UseVisualStyleBackColor = true;
            this.search_Desc.Click += new System.EventHandler(this.search_Desc_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Product # Search";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(296, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Search by description";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(607, 322);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.search_Desc);
            this.Controls.Add(this.descSearchTB);
            this.Controls.Add(this.search_ProductNum);
            this.Controls.Add(this.productSearchTB);
            this.Controls.Add(this.productListBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox productListBox;
        private System.Windows.Forms.TextBox productSearchTB;
        private System.Windows.Forms.Button search_ProductNum;
        private System.Windows.Forms.TextBox descSearchTB;
        private System.Windows.Forms.Button search_Desc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

