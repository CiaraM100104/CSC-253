﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProductSearchLibrary;


/**
* 10/29/2022
* CSC 253
* Ciara McLaughlin
* This program will allow a user to search through a list of products.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        List<Product> products = new List<Product>();  
        public Form1()
        {
            InitializeComponent();
            ProductDisplay();
         
        }

        private void ProductDisplay()
        {
            products = Search.ProductGetter();
            productListBox.Items.Clear();
            productListBox.Items.Add("Product Number  |  Description  |  Units on Hand  |  Price");
            foreach (Product p in products)
            {
                productListBox.Items.Add(p.Product_Number + "  |  " + p.Description + "  |  " + p.Units_On_Hand + "  |  " + p.Price);
            }
        }

        private void search_ProductNum_Click(object sender, EventArgs e)
        {
            products = Search.SearchProductNumber(productSearchTB.Text);
            productListBox.Items.Clear();
            productListBox.Items.Add("Product Number  |  Description  |  Units on Hand  |  Price");
            foreach (Product p in products)
            {
                productListBox.Items.Add(p.Product_Number + "  |  " + p.Description + "  |  " + p.Units_On_Hand + "  |  " + p.Price);
            }
        }

        private void search_Desc_Click(object sender, EventArgs e)
        {
            products = Search.SearchDescription(descSearchTB.Text);
            productListBox.Items.Clear();
            productListBox.Items.Add("Product Number  |  Description  |  Units on Hand  |  Price");
            foreach (Product p in products)
            {
                productListBox.Items.Add(p.Product_Number + "  |  " + p.Description + "  |  " + p.Units_On_Hand + "  |  " + p.Price);
            }
        }
    }
}
