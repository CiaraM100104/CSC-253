﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductSearchLibrary
{

    public class Search
    {

        public static List<Product> ProductGetter()
        {
            ProductDataContext db = new ProductDataContext();
            var results = from product in db.Products
                          select product;
            List<Product> resultList = new List<Product>();
            foreach (var result in results)
            {
                resultList.Add(result);
            }

            return resultList;
        }

        public static List<Product> SearchProductNumber(String input)
        {
            ProductDataContext db = new ProductDataContext();
            var results = from product in db.Products
                          where product.Product_Number == input
                          select product;
            List<Product> resultList = new List<Product>();
            foreach(var result in results)
            {
                resultList.Add(result);
            }
            
            return resultList;
        }

        public static List<Product> SearchDescription(String input)
        {
            ProductDataContext db = new ProductDataContext();
            var results = from product in db.Products
                          where product.Description.Contains(input)
                          select product;
            List<Product> resultList = new List<Product>();
            foreach (var result in results)
            {
                resultList.Add(result);
            }

            return resultList;
        }
    }
}
