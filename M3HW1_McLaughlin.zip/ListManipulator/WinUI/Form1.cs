﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ListManipulatorLibrary;

/**
* 10/2/2022
* CSC 253
* Ciara McLaughlin
* This programs sorts through a list of numbers.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            List<int> numberList = new List<int>();
            numberList = ReadFile.GetList(numberList);
            numberList.RemoveAll(n => n < 0);
            List<int> numberList2 = numberList.FindAll(n => n >= 1 && n <= 10);

            foreach (int number in numberList2)
            {
                numberListBox.Items.Add(number);
            }
        }
    }
}
