﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ListManipulatorLibrary
{
    public class ReadFile
    {
        public static List<int> GetList(List<int> numberList)
        {
            StreamReader inputfile = File.OpenText("random.txt");
            while (!inputfile.EndOfStream)
            {
                numberList.Add(int.Parse(inputfile.ReadLine()));
            }
            inputfile.Close();

            return numberList;
        }
        
    }
}
