﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TuitionIncreaseLibrary
{
    public class TuitionCalc
    {
        public static double CalcuTuition(double tuition)
        {
             double yearlyIncrease = 0.02;

            tuition += (tuition * yearlyIncrease);

            return tuition;
        }
    }
}
