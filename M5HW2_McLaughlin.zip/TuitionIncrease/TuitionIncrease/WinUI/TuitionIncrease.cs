﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TuitionIncreaseLibrary;

/**
* 11/19/2022
* CSC 253
* Ciara McLaughlin
* This program will calculate tuition over the course of 5 years and do a unit test to ensure it calculates properly.
*/

namespace WinUI
{
    public partial class TuitionIncrease : Form
    {
        public TuitionIncrease()
        {
            InitializeComponent();
        }

        private void calcTuitionB_Click(object sender, EventArgs e)
        {
            tuition_LB.Items.Clear();
            double tuition = 6000.00;
            for (int year = 1; year <= 5; year++)
            {
                tuition = TuitionCalc.CalcuTuition(tuition);
                tuition_LB.Items.Add(tuition.ToString("c"));
                tuition_LB.Items.Add("\r\n\r\n" + "\n");
            }
        }
    }
}
