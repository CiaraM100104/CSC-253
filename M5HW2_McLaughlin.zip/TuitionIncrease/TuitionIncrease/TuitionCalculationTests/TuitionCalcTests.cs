﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TuitionIncreaseLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TuitionIncreaseLibrary;

namespace TuitionCalculation.Tests
{
    [TestClass()]
    public class TuitionCalcTests
    {
        [TestMethod()]
        public void CalcuTuitionTest()
        {
            double tuition = 6000.00;
            double expected = 6120.00;

            double actual = TuitionCalc.CalcuTuition(tuition);

            Assert.AreEqual(expected, actual);
        }
    }
}