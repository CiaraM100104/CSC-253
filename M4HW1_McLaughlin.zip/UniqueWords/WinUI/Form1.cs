﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UniqueWordsLibrary;

/**
* 10/23/2022
* CSC 253
* Ciara McLaughlin
* This program displays a list of unique words.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

 

        private void select_Button_Click(object sender, EventArgs e)
        {
            List<string> wordList = new List<string>(); 

            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = ".";

            if(openFileDialog.ShowDialog() == DialogResult.OK)
            {
                wordList = ReadFile.FileReader(openFileDialog.FileName);
                wordsListBox.Items.Clear();

                foreach(string word in wordList)
                {
                    wordsListBox.Items.Add(word);
                }
            }
        }
    }
}
