﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace UniqueWordsLibrary
{
    public class ReadFile
    {
        public static List<string> FileReader(string filename)
        {

            List<string> returnList1 = new List<string>();
            List<string> returnList2 = new List<string>();
            StreamReader inputfile;
            try
            {
                inputfile = File.OpenText(filename);

                while (inputfile.EndOfStream == false)
                {
                    string line = inputfile.ReadLine();
                    line.ToLower();
                    string[] tokens = line.Split(' ');

                    for (int i = 0; i < tokens.Length; i++)
                    {
                        if (char.IsPunctuation(tokens[i][tokens[i].Length - 1]))
                        {
                            tokens[i] = tokens[i].Remove(tokens[i].Length - 1, 1);
                        }

                        returnList1.Add(tokens[i]);
                    }
                    //returnList.Add(inputfile.ReadLine());
                }
                inputfile.Close();

                var sortedList = from w in returnList1
                                 orderby w
                                 select w;
                foreach(string word in sortedList.Distinct())
                {
                    returnList2.Add(word);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }

            
            return returnList2;
        }
    }
}
