﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeSearchLibrary;

/**
* 9/18/2022
* CSC 253
* Ciara McLaughlin
* This program will load a database and allow a user to search it by the name.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        List<Employee> employee = new List<Employee>();
        public Form1()
        {
            InitializeComponent();
            LoadPeopleList();
            WireUpPeopleList();
        }

        private void LoadPeopleList()
        {
            employee = SQLiteDataAccess.LoadPeople();
        }

        private void WireUpPeopleList()
        {
            employeeList.DataSource = null;
            employeeList.DataSource = employee;
            employeeList.DisplayMember = "employeeID";

            nameList.DataSource = null;
            nameList.DataSource = employee;
            nameList.DisplayMember = "name";

            positionList.DataSource = null;
            positionList.DataSource = employee;
            positionList.DisplayMember = "position";

            hourlyRateList.DataSource = null;
            hourlyRateList.DataSource = employee;
            hourlyRateList.DisplayMember = "hourlyPayRate";
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            employee = SQLiteDataAccess.SearchPeople(searchText.Text);
            WireUpPeopleList();
        }
    }
}
