﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeSearchLibrary
{
    public class Employee
    {
        public int employeeID { get; set; }
        public string name { get; set; }
        public string position { get; set; }
        public int hourlyPayRate { get; set; }

        public string PersonId
        {
            get
            {
                return $" { employeeID }";
            }
        }
    }
}
