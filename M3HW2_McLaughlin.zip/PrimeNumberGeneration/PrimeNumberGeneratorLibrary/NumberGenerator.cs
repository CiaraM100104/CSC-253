﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimeNumberGeneratorLibrary
{
    public class NumberGenerator
    {
        public static List<int> GetNumbers(int userinput, List<int> numberList)
        {
            for (int i = 1; i <= userinput; i++)
            {
                    numberList.Add(i);
            }
            return numberList;
        }
    }
}
