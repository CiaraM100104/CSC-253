﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PrimeNumberGeneratorLibrary;

/**
* 10/2/2022
* CSC 253
* Ciara McLaughlin
* This programs generates prime numbers based off user input.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            
            InitializeComponent();
        }

        private void primeNumberButton_Click(object sender, EventArgs e)
        {
            List<int> numberList = new List<int>();
            int userNum = int.Parse(userNumText.Text);
            numberList = NumberGenerator.GetNumbers(userNum, numberList);
            numberList = numberList.FindAll(n => n % 2 != 0);

            foreach (int number in numberList)
            {
                primeNumList.Items.Add(number);
            }
        }
    }
}
