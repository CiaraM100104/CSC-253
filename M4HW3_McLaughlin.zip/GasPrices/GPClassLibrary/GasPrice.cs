﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GPClassLibrary
{
    public class GasPrice
    {
        public GasPrice()
        {

        }
        public GasPrice(int month, int day, int year, double price)
        {
            month = Month;
            day = Day;
            year = Year;
            price = Price;
        }

        public int Month { get; set; }
        public int Day { get; set; }

        public int Year { get; set; }

        public double Price { get; set; }

        public static List<string> gasList = ReadFile.FileReader("GasPrices.txt");
        public static List<GasPrice> gasPrices = new List<GasPrice>();

        public static void gasPriceGetter()
        {
            foreach(string price in gasList)
            {
                string[] tokens = price.Split(':');
                double.TryParse(tokens[1], out double gasPrice);
                string[] tokens2 = tokens[0].Split('-');
                int.TryParse(tokens2[0], out int month);
                int.TryParse(tokens2[1], out int day);
                int.TryParse(tokens2[2], out int year);
                GasPrice gasPricesList = new GasPrice();
                gasPricesList.Month = month;
                gasPricesList.Day = day;
                gasPricesList.Year = year;
                gasPricesList.Price = gasPrice;
                gasPrices.Add(gasPricesList);
            }

        }
    }
}
