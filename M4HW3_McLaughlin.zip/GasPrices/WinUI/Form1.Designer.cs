﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pricesListBox = new System.Windows.Forms.ListBox();
            this.avgPerYear_button = new System.Windows.Forms.Button();
            this.avgPriceMonth_button = new System.Windows.Forms.Button();
            this.HiandLow_button = new System.Windows.Forms.Button();
            this.TFLowtoHigh_button = new System.Windows.Forms.Button();
            this.TF_HightoLow_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // pricesListBox
            // 
            this.pricesListBox.FormattingEnabled = true;
            this.pricesListBox.Location = new System.Drawing.Point(12, 121);
            this.pricesListBox.Name = "pricesListBox";
            this.pricesListBox.Size = new System.Drawing.Size(343, 264);
            this.pricesListBox.TabIndex = 0;
            // 
            // avgPerYear_button
            // 
            this.avgPerYear_button.Location = new System.Drawing.Point(12, 12);
            this.avgPerYear_button.Name = "avgPerYear_button";
            this.avgPerYear_button.Size = new System.Drawing.Size(155, 23);
            this.avgPerYear_button.TabIndex = 1;
            this.avgPerYear_button.Text = "Average Price Per Year";
            this.avgPerYear_button.UseVisualStyleBackColor = true;
            this.avgPerYear_button.Click += new System.EventHandler(this.avgPerYear_button_Click);
            // 
            // avgPriceMonth_button
            // 
            this.avgPriceMonth_button.Location = new System.Drawing.Point(173, 12);
            this.avgPriceMonth_button.Name = "avgPriceMonth_button";
            this.avgPriceMonth_button.Size = new System.Drawing.Size(169, 23);
            this.avgPriceMonth_button.TabIndex = 2;
            this.avgPriceMonth_button.Text = "Average Price Per Month";
            this.avgPriceMonth_button.UseVisualStyleBackColor = true;
            this.avgPriceMonth_button.Click += new System.EventHandler(this.avgPriceMonth_button_Click);
            // 
            // HiandLow_button
            // 
            this.HiandLow_button.Location = new System.Drawing.Point(107, 41);
            this.HiandLow_button.Name = "HiandLow_button";
            this.HiandLow_button.Size = new System.Drawing.Size(155, 23);
            this.HiandLow_button.TabIndex = 3;
            this.HiandLow_button.Text = "Highest and Lowest Per Year";
            this.HiandLow_button.UseVisualStyleBackColor = true;
            this.HiandLow_button.Click += new System.EventHandler(this.HiandLow_button_Click);
            // 
            // TFLowtoHigh_button
            // 
            this.TFLowtoHigh_button.Location = new System.Drawing.Point(13, 77);
            this.TFLowtoHigh_button.Name = "TFLowtoHigh_button";
            this.TFLowtoHigh_button.Size = new System.Drawing.Size(154, 23);
            this.TFLowtoHigh_button.TabIndex = 4;
            this.TFLowtoHigh_button.Text = "Get Text File Low to High";
            this.TFLowtoHigh_button.UseVisualStyleBackColor = true;
            this.TFLowtoHigh_button.Click += new System.EventHandler(this.TFLowtoHigh_button_Click);
            // 
            // TF_HightoLow_button
            // 
            this.TF_HightoLow_button.Location = new System.Drawing.Point(174, 76);
            this.TF_HightoLow_button.Name = "TF_HightoLow_button";
            this.TF_HightoLow_button.Size = new System.Drawing.Size(168, 23);
            this.TF_HightoLow_button.TabIndex = 5;
            this.TF_HightoLow_button.Text = "Get Text File High to Low";
            this.TF_HightoLow_button.UseVisualStyleBackColor = true;
            this.TF_HightoLow_button.Click += new System.EventHandler(this.TF_HightoLow_button_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(365, 397);
            this.Controls.Add(this.TF_HightoLow_button);
            this.Controls.Add(this.TFLowtoHigh_button);
            this.Controls.Add(this.HiandLow_button);
            this.Controls.Add(this.avgPriceMonth_button);
            this.Controls.Add(this.avgPerYear_button);
            this.Controls.Add(this.pricesListBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox pricesListBox;
        private System.Windows.Forms.Button avgPerYear_button;
        private System.Windows.Forms.Button avgPriceMonth_button;
        private System.Windows.Forms.Button HiandLow_button;
        private System.Windows.Forms.Button TFLowtoHigh_button;
        private System.Windows.Forms.Button TF_HightoLow_button;
    }
}

