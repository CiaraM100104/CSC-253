﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GPClassLibrary;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;


/**
* 10/29/2022
* CSC 253
* Ciara McLaughlin
* This program allows a user to get averages as well as sort through gas prices.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            GasPrice.gasPriceGetter();
            ShowPrices();
        }

        private void ShowPrices()
        {
            foreach(GasPrice gasprice in GasPrice.gasPrices)
            {
                pricesListBox.Items.Add(gasprice.Month + "-" + gasprice.Day + "-" + gasprice.Year + ": " + gasprice.Price);
            }
            


        }

        private void TF_HightoLow_button_Click(object sender, EventArgs e)
        {
            StreamWriter outputFile;

            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = ".";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string path;
                path = saveFileDialog.FileName;
                outputFile = File.CreateText(saveFileDialog.FileName + ".txt");
                string fileName = saveFileDialog.FileName;
                var results = from prices in GasPrice.gasPrices
                              orderby prices.Price descending
                              select prices;
                foreach (var result in results)
                {
                    outputFile.WriteLine(result.Month + "-" + result.Day + "-" + result.Year + " : " + result.Price);
                }

                outputFile.Close();
            }
            else
            {
                MessageBox.Show("Cancelled.");
            }
        }

        private void TFLowtoHigh_button_Click(object sender, EventArgs e)
        {
            StreamWriter outputFile;
            
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = ".";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string path;
                path = saveFileDialog.FileName;
                outputFile = File.CreateText(saveFileDialog.FileName + ".txt");
                string fileName = saveFileDialog.FileName;
                var results = from prices in GasPrice.gasPrices
                              orderby prices.Price
                              select prices;
                foreach(var result in results)
                {
                    outputFile.WriteLine(result.Month + "-" + result.Day + "-" + result.Year + " : " + result.Price);
                }
                
                outputFile.Close();
            }
            else
            {
                MessageBox.Show("Cancelled.");
            }
        }

        private void avgPerYear_button_Click(object sender, EventArgs e)
        {
            pricesListBox.Items.Clear();

            for (int i = 1993; i < 2014; i++)
            {
                pricesListBox.Items.Add(i + " " + GasPrice.gasPrices.Where(n => n.Year == i).Average(n => n.Price).ToString("c2"));
                
            }

            
        }

        private void avgPriceMonth_button_Click(object sender, EventArgs e)
        {
            pricesListBox.Items.Clear();

            for (int i = 1; i < 13; i++)
            {
                pricesListBox.Items.Add(i + " " + GasPrice.gasPrices.Where(n => n.Month == i).Average(n => n.Price).ToString("c2"));

            }
        }

        private void HiandLow_button_Click(object sender, EventArgs e)
        {
            pricesListBox.Items.Clear();

            for (int i = 1993; i < 2014; i++)
            {
                pricesListBox.Items.Add("Lowest Price: " + i + " " + GasPrice.gasPrices.Where(n => n.Year == i).Min(n => n.Price).ToString("c2"));
                pricesListBox.Items.Add("Highest Price: " + i + " " + GasPrice.gasPrices.Where(n => n.Year == i).Max(n => n.Price).ToString("c2"));
            }

   
        }
    }
}
