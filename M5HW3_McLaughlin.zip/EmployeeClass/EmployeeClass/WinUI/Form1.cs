﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeClassLibrary;

/**
* 11/19/2022
* CSC 253
* Ciara McLaughlin
* This program makes a class for employees, makes 3 objects for them and then displays them
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void displayInfo_Click(object sender, EventArgs e)
        {
            EmployeeClass employee1 = new EmployeeClass("Susan Meyers", 47899, "Accounting", "Vice President");
            EmployeeClass employee2 = new EmployeeClass("Mark Jones", 39119, "IT", "Programmer");
            EmployeeClass employee3 = new EmployeeClass("Joy Rogers", 81774, "Manufacturing", "Engineer");

            nameBox.Items.Add(employee1.name);
            nameBox.Items.Add(employee2.name);
            nameBox.Items.Add(employee3.name);

            idBox.Items.Add(employee1.idNumber);
            idBox.Items.Add(employee2.idNumber);
            idBox.Items.Add(employee3.idNumber);

            departmentBox.Items.Add(employee1.department);
            departmentBox.Items.Add(employee2.department);
            departmentBox.Items.Add(employee3.department);

            positionBox.Items.Add(employee1.position);
            positionBox.Items.Add(employee2.position);
            positionBox.Items.Add(employee3.position);


        }
    }
}
