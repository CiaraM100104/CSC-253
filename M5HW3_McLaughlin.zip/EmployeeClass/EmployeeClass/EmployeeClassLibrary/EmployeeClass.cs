﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeClassLibrary
{
    public class EmployeeClass
    {
        private string _name;
        private int _idNumber;
        private string _department;
        private string _position;

        public EmployeeClass(string name, int idNumber, string department, string position)
        {
            _name = name;
            _idNumber = idNumber;
            _department = department;
            _position = position;
        }

        public EmployeeClass(string name, int idNumber)
        {
            _name = name;
            _idNumber = idNumber;
            _department = "";
            _position = "";
        }

        public EmployeeClass()
        {
            _name = "";
            _idNumber = 0;
            _department = "";
            _position = "";

        }

        public string name
        {
            get { return _name; }
            set { }
        }

        public int idNumber
        {
            get { return _idNumber; }
            set { }
        }

        public string department
        {
            get { return _department; }
            set { }
        }

        public string position
        {
            get { return _position; }
            set { }
        }
    }
}
