﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CelsiusToFahrenheitClassLibrary;

/**
* 8/20/2022
* CSC 253
* Ciara McLaughlin
* This program displays celsius from 1-20 and displays their fahrenheit equivalents.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            double celsiusAmount;
            double fahrenheitAmount;

            temperatureListBox.Items.Add("Celsius\tFahrenheit");

            for (celsiusAmount = 0; celsiusAmount <= 20; celsiusAmount++)
            {
                fahrenheitAmount = TemperatureClass.getFahrenheit(ref celsiusAmount);
                temperatureListBox.Items.Add(celsiusAmount + "\t" + fahrenheitAmount);
            }
        }
    }
}
