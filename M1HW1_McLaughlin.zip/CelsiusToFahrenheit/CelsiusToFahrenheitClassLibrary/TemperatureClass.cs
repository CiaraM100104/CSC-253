﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CelsiusToFahrenheitClassLibrary
{
    public class TemperatureClass
    {
        public static double getFahrenheit (ref double celsius)
        {
            double fahrenheit = 0; 

                fahrenheit = (9.0 / 5.0) * celsius + 32;
               
            return fahrenheit;
        }

    }
}
