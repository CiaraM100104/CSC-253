﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using KEClassLibrary;

/**
* 8/20/2022
* CSC 253
* Ciara McLaughlin
* This program will calculate the kinetic energy based on the mass and velocity the user inputs.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calcEnergy_Click(object sender, EventArgs e)
        {
            double massAmount;
            double velocityAmount;
            double kineticEnergy;
            if (double.TryParse(massTextBox.Text, out massAmount) && double.TryParse(veloTextBox.Text, out velocityAmount))
            {
                kineticEnergy = KEClass.KineticEnergy(ref massAmount, velocityAmount);
                kineticEnergyTextBox.Text = kineticEnergy.ToString("n");
            }
            else
            {
                MessageBox.Show("Please enter valid numbers", "Invalid Input");
            }
        }
    }
}
