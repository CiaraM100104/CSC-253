﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KEClassLibrary
{
   public class KEClass
    {
        public static double KineticEnergy(ref double mass, double velocity)
        {
            double kineticEnergy = 0.5 * mass * Math.Pow(velocity, 2);
            return kineticEnergy;
        }
    }
}
